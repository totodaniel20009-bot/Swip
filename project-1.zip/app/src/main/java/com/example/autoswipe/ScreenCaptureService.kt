// 위치: app/src/main/java/com/example/autoswipe/ScreenCaptureService.kt
package com.example.autoswipe

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager

/**
 * 화면을 캡처해서 RingDetector 로 '줄어드는 링'을 분석하고,
 * 타격 시점이 되면 접근성 서비스로 설정된 타법을 실행한다.
 *
 * 성능: 화면 짧은 변을 540px 로 줄여서 캡처, 관심영역만 복사, 약 30fps 로만 분석,
 *       버퍼는 시작할 때 한 번만 할당(프레임마다 새로 만들지 않음).
 */
class ScreenCaptureService : Service() {

    companion object {
        private const val TAG = "ScreenCapture"
        const val ACTION_START = "com.example.autoswipe.START"
        const val ACTION_STOP = "com.example.autoswipe.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"

        @Volatile
        var isRunning = false

        private const val CHANNEL_ID = "autoswipe_capture"
        private const val NOTI_ID = 1001

        private const val BASE_SHORT_SIDE = 540          // 캡처 해상도 기준(짧은 변)
        private const val MIN_INTERVAL_NS = 28_000_000L  // 분석 간격 (약 30fps)
        private const val ROI_X0 = 0.15f                 // 관심영역: 영상에서 링이 나타난 범위
        private const val ROI_X1 = 0.85f
        private const val ROI_Y0 = 0.30f
        private const val ROI_Y1 = 0.93f
        private const val MIN_RETRIGGER_MS = 350L        // 연속 타격 방지
    }

    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var bgThread: HandlerThread? = null
    private var bgHandler: Handler? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private var detector: RingDetector? = null
    private lateinit var roiBuf: ByteArray
    private var roiX0 = 0
    private var roiY0 = 0
    private var roiW = 0
    private var roiH = 0

    private var lastTs = 0L
    private var cfg: Cfg = Cfg(0, 66, 70, 12, 220, 120, 14)
    private var cfgLoadedAt = 0L
    private var lastFireMs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (isRunning) return START_NOT_STICKY

        // Android 14: getMediaProjection() 이전에 mediaProjection 타입으로 startForeground() 필수
        createChannel()
        val noti = buildNotification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTI_ID, noti, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(NOTI_ID, noti)
        }

        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        }
        if (resultCode != Activity.RESULT_OK || data == null) {
            Log.e(TAG, "MediaProjection 데이터 없음")
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            startCapture(resultCode, data)
            isRunning = true
        } catch (e: Exception) {
            Log.e(TAG, "캡처 시작 실패", e)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        bgThread = HandlerThread("AutoSwipeAnalyzer").also { it.start() }
        bgHandler = Handler(bgThread!!.looper)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val proj = mpm.getMediaProjection(resultCode, data)
        projection = proj

        // Android 14+: createVirtualDisplay 전에 콜백 등록 필수
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                mainHandler.post { stopSelf() }
            }
        }
        proj.registerCallback(projectionCallback!!, bgHandler)

        // 캡처 크기: 짧은 변을 540px 로 (반지름 상수가 이 기준)
        val (sw, sh) = realScreenSize()
        val scale = BASE_SHORT_SIDE.toFloat() / minOf(sw, sh)
        val capW = (sw * scale).toInt() / 2 * 2
        val capH = (sh * scale).toInt() / 2 * 2

        roiX0 = (capW * ROI_X0).toInt()
        val roiX1 = (capW * ROI_X1).toInt()
        roiY0 = (capH * ROI_Y0).toInt()
        val roiY1 = (capH * ROI_Y1).toInt()
        roiW = roiX1 - roiX0
        roiH = roiY1 - roiY0
        roiBuf = ByteArray(roiW * roiH * 4)       // 시작 시 한 번만 할당
        detector = RingDetector(roiW, roiH)

        // maxImages = 2, 최신 프레임만 사용
        val reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        reader.setOnImageAvailableListener({ r -> onFrame(r) }, bgHandler)

        val dpi = resources.displayMetrics.densityDpi
        virtualDisplay = proj.createVirtualDisplay(
            "AutoSwipeCapture", capW, capH, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, bgHandler
        )
        Log.d(TAG, "캡처 시작: ${capW}x$capH, ROI ${roiW}x$roiH")
    }

    // ===================== 프레임 처리 (백그라운드 스레드) =====================

    private fun onFrame(reader: ImageReader) {
        val image: Image = try {
            reader.acquireLatestImage()
        } catch (e: Exception) {
            null
        } ?: return
        try {
            val ts = image.timestamp
            if (ts - lastTs < MIN_INTERVAL_NS) return   // 너무 자주 오는 프레임은 건너뜀
            lastTs = ts
            val det = detector ?: return

            // 설정은 1초에 한 번만 다시 읽음
            val now = SystemClock.elapsedRealtime()
            if (now - cfgLoadedAt > 1000) {
                cfg = Config.load(this)
                cfgLoadedAt = now
            }
            det.leadSec = cfg.leadMs / 1000.0
            det.targetRadius = cfg.target.toDouble()

            // 관심영역만 한 줄씩 통째로 복사 (픽셀 단위 접근보다 훨씬 빠름)
            val plane = image.planes[0]
            val buf = plane.buffer
            val rs = plane.rowStride
            val rowBytes = roiW * 4
            for (y in 0 until roiH) {
                buf.position((roiY0 + y) * rs + roiX0 * 4)
                buf.get(roiBuf, y * rowBytes, rowBytes)
            }

            if (det.process(roiBuf, ts / 1_000_000_000.0)) {
                if (now - lastFireMs >= MIN_RETRIGGER_MS) {
                    lastFireMs = now
                    val c = cfg
                    mainHandler.post { AutoSwipeAccessibilityService.instance?.performStroke(c) }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "프레임 처리 오류", e)
        } finally {
            image.close() // 누수 방지: 반드시 닫음
        }
    }

    // ===================== 종료 / 정리 =====================

    override fun onDestroy() {
        isRunning = false
        mainHandler.removeCallbacksAndMessages(null)
        bgHandler?.removeCallbacksAndMessages(null)

        // 해제 순서: 리스너 -> VirtualDisplay -> ImageReader -> MediaProjection -> 스레드
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Exception) {}
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try {
            projectionCallback?.let { projection?.unregisterCallback(it) }
            projection?.stop()
        } catch (_: Exception) {}
        projection = null
        projectionCallback = null
        detector = null
        bgThread?.quitSafely()
        bgThread = null
        bgHandler = null

        super.onDestroy()
    }

    private fun realScreenSize(): Pair<Int, Int> {
        val wm = getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "화면 캡처", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, ScreenCaptureService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("AutoSwipe 실행 중")
            .setContentText("링을 감시하고 있습니다.")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .addAction(Notification.Action.Builder(null, "중지", stopIntent).build())
            .setOngoing(true)
            .build()
    }
}
