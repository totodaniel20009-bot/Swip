// 위치: app/src/main/java/com/example/autoswipe/MainActivity.kt
package com.example.autoswipe

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var statusText: TextView

    // MediaProjection 권한 요청 결과 처리
    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val intent = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_START
                    putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
                }
                // 서비스 안에서 startForeground() 를 먼저 호출한 뒤 MediaProjection 을 생성함
                ContextCompat.startForegroundService(this, intent)
                Toast.makeText(this, "시작됨: 게임 화면으로 이동하세요", Toast.LENGTH_LONG).show()
                moveTaskToBack(true)
            } else {
                Toast.makeText(this, "화면 캡처 권한이 거부되었습니다.", Toast.LENGTH_SHORT).show()
            }
            updateStatus()
        }

    // 알림 권한 (Android 13+) 요청 결과 처리: 거부돼도 진행
    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            requestProjection()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        statusText = TextView(this).apply { textSize = 16f }
        root.addView(statusText)

        root.addView(Button(this).apply {
            text = "1. 접근성 서비스 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "2. 화면 캡처 시작"
            setOnClickListener { onStartClicked() }
        })
        root.addView(Button(this).apply {
            text = "중지"
            setOnClickListener {
                stopService(Intent(this@MainActivity, ScreenCaptureService::class.java))
                updateStatus()
            }
        })

        // ---------- 타법 선택 ----------
        root.addView(TextView(this).apply {
            text = "\n타법 (링이 목표에 닿을 때마다 이 동작을 반복)"
            textSize = 16f
        })
        val prefs = Config.prefs(this)
        val names = listOf(
            "커트: 위로 올렸다가 아래로 쓸어내리기",
            "드라이브: 아래로 당겼다가 위로 밀기",
            "블록: 톡 (탭)",
            "섞어서 (랜덤)"
        )
        val rg = RadioGroup(this)
        names.forEachIndexed { i, name ->
            rg.addView(RadioButton(this).apply { id = 100 + i; text = name })
        }
        rg.check(100 + prefs.getInt("stroke", Config.STROKE_CUT).coerceIn(0, 3))
        rg.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("stroke", id - 100).apply()
        }
        root.addView(rg)

        // ---------- 세부 조절 ----------
        root.addView(TextView(this).apply { text = "\n세부 설정"; textSize = 16f })
        addSeek(root, "스와이프 가로 위치", "x", 5, 95, 66, "%")
        addSeek(root, "스와이프 세로 위치", "y", 10, 90, 70, "%")
        addSeek(root, "위/아래 이동 거리", "len", 3, 30, 12, "%")
        addSeek(root, "동작 시간", "dur", 80, 600, 220, "ms")
        addSeek(root, "타이밍 앞당김 (클수록 빨리 침)", "lead", 0, 500, 120, "ms")
        addSeek(root, "목표 링 크기", "target", 8, 30, 14, "px")

        // ---------- 테스트 ----------
        root.addView(Button(this).apply {
            text = "테스트 타격 (3초 뒤 1회, 게임 화면으로 이동)"
            setOnClickListener {
                Toast.makeText(this@MainActivity, "3초 뒤 실행됩니다", Toast.LENGTH_SHORT).show()
                Handler(Looper.getMainLooper()).postDelayed({
                    val svc = AutoSwipeAccessibilityService.instance
                    if (svc == null) {
                        Toast.makeText(this@MainActivity, "접근성 서비스가 꺼져 있습니다", Toast.LENGTH_LONG).show()
                    } else {
                        svc.performStroke(Config.load(this@MainActivity))
                    }
                }, 3000)
            }
        })

        setContentView(ScrollView(this).apply { addView(root) })
    }

    /** 슬라이더 한 줄 (값은 바로 저장됨) */
    private fun addSeek(
        parent: LinearLayout, title: String, key: String,
        lo: Int, hi: Int, def: Int, unit: String
    ) {
        val prefs = Config.prefs(this)
        val cur = prefs.getInt(key, def).coerceIn(lo, hi)
        val label = TextView(this).apply { text = "$title: $cur$unit" }
        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = cur - lo
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                label.text = "$title: $v$unit"
                prefs.edit().putInt(key, v).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        parent.addView(label)
        parent.addView(bar)
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
    }

    private fun onStartClicked() {
        if (!isAccessibilityEnabled()) {
            Toast.makeText(this, "먼저 접근성 서비스를 켜 주세요.", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestProjection()
        }
    }

    private fun requestProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    // 설정에 저장된 활성 접근성 서비스 목록에서 내 서비스를 찾음
    private fun isAccessibilityEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val cn = ComponentName(this, AutoSwipeAccessibilityService::class.java)
        return enabled.split(':').any {
            it.equals(cn.flattenToString(), ignoreCase = true) ||
                it.equals(cn.flattenToShortString(), ignoreCase = true)
        }
    }

    private fun updateStatus() {
        val acc = if (isAccessibilityEnabled()) "ON" else "OFF"
        val cap = if (ScreenCaptureService.isRunning) "실행 중" else "중지"
        statusText.text = "접근성 서비스: $acc\n화면 캡처: $cap"
    }
}
