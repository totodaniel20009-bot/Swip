// 위치: app/src/main/java/com/example/autoswipe/RingDetector.kt
package com.example.autoswipe

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 게임 화면의 '줄어드는 링'(빨강/파랑)을 찾아 추적하고,
 * 링 반지름이 목표 반지름에 닿기 leadSec 초 전에 true 를 돌려주는 분석기.
 * 안드로이드 클래스에 의존하지 않는 순수 Kotlin 이라 PC에서 영상 프레임으로도 검증할 수 있습니다.
 *
 * 입력: 관심영역(ROI)을 잘라낸 RGBA 바이트 배열 (roiW * roiH * 4)
 * 기준 해상도: 화면 짧은 변 540px 기준으로 반지름 상수를 잡았습니다.
 */
class RingDetector(private val roiW: Int, private val roiH: Int) {

    companion object {
        const val STATIC_LAG = 6            // 6프레임 전과 비교해서 '새로 생긴' 픽셀만 사용 (정지된 빨강/파랑 물체 제거)
        private const val SLOTS = STATIC_LAG + 1
        private const val RMIN = 13         // 링 탐색 최소 반지름
        private const val RMAX = 48         // 링 탐색 최대 반지름
        private const val NB = 24           // 원 둘레 각도 구간 수
        private const val NEW_CAP = 8192
        private const val COOL_FRAMES = 15  // 추적 종료 후 재탐색 금지 프레임
        private const val LOST_FRAMES = 22  // 링이 안 보여도 기다리는 최대 프레임
        private const val LOST_AFTER_TRIGGER = 3
        private const val MAX_TRACK_SEC = 3.0
        private const val SLOPE_MIN = -9.0  // 반지름이 초당 9px 이상 줄어야 '수축 중'
    }

    /** 이 반지름(px)에 도달하는 시점을 타격 시점으로 본다. */
    @Volatile var targetRadius = 14.0
    /** 도달 예상 시각보다 이만큼(초) 먼저 신호를 낸다. (제스처 지연 보정) */
    @Volatile var leadSec = 0.12

    /** 디버그용: 마지막으로 측정한 링 반지름 */
    var lastRadius = 0.0
        private set
    val isTracking: Boolean get() = tracking

    private val ONE: Byte = 1
    private val ZERO: Byte = 0
    private val n = roiW * roiH

    // 색상별 마스크 (0 = 파랑, 1 = 빨강)
    private val curMask = Array(2) { ByteArray(n) }
    private val hist = Array(2) { Array(SLOTS) { ByteArray(n) } }
    private val tmp = ByteArray(n)

    // '새로 생긴' 픽셀 좌표
    private val newX = Array(2) { IntArray(NEW_CAP) }
    private val newY = Array(2) { IntArray(NEW_CAP) }
    private val newTotal = IntArray(2)

    // 허프 변환 버퍼 (프레임마다 새로 할당하지 않음)
    private val radii = IntArray((RMAX - RMIN) / 2 + 1) { RMIN + it * 2 }
    private val dxT: Array<IntArray> = Array(radii.size) { ri ->
        val r = radii[ri]
        val nr = max(16, (2 * PI * r / 1.5).toInt())
        IntArray(nr) { k -> Math.rint(r * cos(2 * PI * k / nr)).toInt() }
    }
    private val dyT: Array<IntArray> = Array(radii.size) { ri ->
        val r = radii[ri]
        val nr = max(16, (2 * PI * r / 1.5).toInt())
        IntArray(nr) { k -> Math.rint(r * sin(2 * PI * k / nr)).toInt() }
    }
    private val aw = roiW / 2 + 1
    private val ah = roiH / 2 + 1
    private val acc = IntArray(aw * ah)
    private val rh = DoubleArray(RMAX + 16)

    // 허프/커버리지 결과
    private var hCx = 0
    private var hCy = 0
    private var hR = 0
    private var covOut = 0.0
    private var cntOut = 0
    private var innerOut = 0
    private var resR = 0.0

    private var frameNo = 0
    private var coolUntil = 0

    // 후보(연속 2프레임 같은 자리에서 보이면 확정)
    private var candColor = -1
    private var candCx = 0
    private var candCy = 0

    // 추적 상태
    private var tracking = false
    private var trkColor = 0
    private var trkCx = 0
    private var trkCy = 0
    private var trkMiss = 0
    private var trkTrig = false
    private var trkT0 = 0.0
    private val trkT = DoubleArray(512)
    private val trkR = DoubleArray(512)
    private var trkN = 0

    /**
     * 프레임 한 장을 처리합니다.
     * @param tSec 프레임 시각(초)
     * @return 지금 타격해야 하면 true (링 한 개당 한 번만)
     */
    fun process(rgba: ByteArray, tSec: Double): Boolean {
        buildMasks(rgba)
        var fired = false
        if (frameNo >= STATIC_LAG) {
            extractNew()
            fired = step(tSec)
        }
        val slot = frameNo % SLOTS
        dilateInto(curMask[0], hist[0][slot])
        dilateInto(curMask[1], hist[1][slot])
        frameNo++
        return fired
    }

    // ---------------------------------------------------------------- 마스크

    private fun buildMasks(rgba: ByteArray) {
        val blue = curMask[0]
        val red = curMask[1]
        var p = 0
        for (i in 0 until n) {
            val r = rgba[p].toInt() and 255
            val g = rgba[p + 1].toInt() and 255
            val b = rgba[p + 2].toInt() and 255
            p += 4
            val gr = g - r
            val br = b - r
            blue[i] = if (gr in 8..60 && br in 55..140 && b in 140..235 && g >= 85) ONE else ZERO
            red[i] = if (r - b >= 45 && r >= 120 && r - g >= 70) ONE else ZERO
        }
    }

    /** 3x3 팽창: 약간 움직인 정지 물체를 '새 픽셀'로 오인하지 않게 함 */
    private fun dilateInto(src: ByteArray, dst: ByteArray) {
        for (y in 0 until roiH) {
            val o = y * roiW
            for (x in 0 until roiW) {
                var v = src[o + x]
                if (v == ZERO && y > 0) v = src[o - roiW + x]
                if (v == ZERO && y < roiH - 1) v = src[o + roiW + x]
                tmp[o + x] = v
            }
        }
        for (y in 0 until roiH) {
            val o = y * roiW
            for (x in 0 until roiW) {
                var v = tmp[o + x]
                if (v == ZERO && x > 0) v = tmp[o + x - 1]
                if (v == ZERO && x < roiW - 1) v = tmp[o + x + 1]
                dst[o + x] = v
            }
        }
    }

    private fun extractNew() {
        val oldSlot = (frameNo + 1) % SLOTS   // = 6프레임 전 슬롯
        for (c in 0..1) {
            val cur = curMask[c]
            val old = hist[c][oldSlot]
            val xs = newX[c]
            val ys = newY[c]
            var cnt = 0
            for (y in 0 until roiH) {
                val o = y * roiW
                for (x in 0 until roiW) {
                    val i = o + x
                    if (cur[i] != ZERO && old[i] == ZERO) {
                        if (cnt < NEW_CAP) {
                            xs[cnt] = x
                            ys[cnt] = y
                        }
                        cnt++
                    }
                }
            }
            newTotal[c] = cnt
        }
    }

    // ---------------------------------------------------------------- 상태 머신

    private fun step(t: Double): Boolean {
        if (!tracking) {
            if (frameNo < coolUntil) return false
            findRing()
            return false
        }
        return trackRing(t)
    }

    /** 대기 상태: 새로 생긴 픽셀로 원(링)을 찾아 후보 → 확정 */
    private fun findRing() {
        var bestW = -1.0
        var bc = -1
        var bcx = 0
        var bcy = 0
        var br = 0
        for (c in 0..1) {
            val cnt = newTotal[c]
            if (cnt < 70 || cnt > NEW_CAP) continue
            if (!hough(newX[c], newY[c], cnt)) continue
            val cx = hCx
            val cy = hCy
            val r = hR
            coverage(newX[c], newY[c], cnt, cx.toDouble(), cy.toDouble(), r.toDouble())
            if (covOut >= 0.6 && innerOut <= 0.3 * max(cntOut, 1) && cntOut >= 0.6 * PI * r) {
                val w = covOut * cntOut
                if (w > bestW) {
                    bestW = w; bc = c; bcx = cx; bcy = cy; br = r
                }
            }
        }
        if (bc < 0) {
            candColor = -1
            return
        }
        if (candColor == bc && abs(candCx - bcx) <= 4 && abs(candCy - bcy) <= 4) {
            tracking = true
            trkColor = bc
            trkCx = bcx
            trkCy = bcy
            trkMiss = 0
            trkTrig = false
            trkN = 0
            trkT0 = 0.0
            lastRadius = br.toDouble()
            candColor = -1
            pendingStartR = br.toDouble()
            needStartT = true
        } else {
            candColor = bc
            candCx = bcx
            candCy = bcy
        }
    }

    private var pendingStartR = 0.0
    private var needStartT = false

    /** 추적 상태: 링 반지름 변화를 따라가며 도달 시점을 예측 */
    private fun trackRing(t: Double): Boolean {
        var fired = false
        if (needStartT) {            // 확정된 프레임의 시각으로 시작 샘플 기록
            needStartT = false
            trkT0 = t
            addSample(t, pendingStartR)
            return false
        }
        val c = trkColor
        val ok = newTotal[c] in 8..NEW_CAP &&
            radiusGated(c, trkCx, trkCy, trkR[trkN - 1]) && covOut >= 0.3 && cntOut >= 25

        if (!ok) {
            trkMiss++
            if (!trkTrig) {          // 링이 가려진 경우: 직전 속도로 반지름을 외삽해서 판단
                val s = slope()
                if (!s.isNaN() && s < SLOPE_MIN) {
                    val rEst = trkR[trkN - 1] + s * (t - trkT[trkN - 1])
                    if ((rEst - targetRadius) / (-s) <= leadSec) {
                        trkTrig = true
                        fired = true
                    }
                }
            }
            if (trkMiss >= LOST_FRAMES || (trkTrig && trkMiss >= LOST_AFTER_TRIGGER)) endTrack()
        } else {
            trkMiss = 0
            addSample(t, resR)
            lastRadius = resR
            if (!trkTrig) {
                val s = slope()
                if (!s.isNaN()) {
                    if (s < SLOPE_MIN) {
                        val ttt = (resR - targetRadius) / (-s)
                        if (ttt <= leadSec) {
                            trkTrig = true
                            fired = true
                        }
                    }
                    if (!trkTrig && resR <= targetRadius + 0.5) {
                        trkTrig = true
                        fired = true
                    }
                }
            }
        }
        if (tracking && t - trkT0 > MAX_TRACK_SEC) endTrack()
        return fired
    }

    private fun endTrack() {
        tracking = false
        coolUntil = frameNo + COOL_FRAMES
        candColor = -1
    }

    private fun addSample(t: Double, r: Double) {
        if (trkN < trkT.size) {
            trkT[trkN] = t
            trkR[trkN] = r
            trkN++
        }
    }

    /** 최근 최대 6개 샘플의 반지름 변화율(px/초). 샘플이 4개 미만이면 NaN */
    private fun slope(): Double {
        val k = min(trkN, 6)
        if (k < 4) return Double.NaN
        var st = 0.0
        var sr = 0.0
        for (i in trkN - k until trkN) { st += trkT[i]; sr += trkR[i] }
        val mt = st / k
        val mr = sr / k
        var num = 0.0
        var den = 0.0
        for (i in trkN - k until trkN) {
            val dt = trkT[i] - mt
            num += dt * (trkR[i] - mr)
            den += dt * dt
        }
        return if (den < 1e-9) Double.NaN else num / den
    }

    // ---------------------------------------------------------------- 도형 계산

    /** 원형 허프 변환: 새 픽셀들이 만드는 가장 그럴듯한 원의 중심/반지름 */
    private fun hough(xs: IntArray, ys: IntArray, cnt: Int): Boolean {
        var bestScore = 0.0
        var found = false
        for (ri in radii.indices) {
            val dxs = dxT[ri]
            val dys = dyT[ri]
            val nr = dxs.size
            java.util.Arrays.fill(acc, 0)
            for (p in 0 until cnt) {
                val px = xs[p]
                val py = ys[p]
                for (k in 0 until nr) {
                    val cx = px - dxs[k]
                    val cy = py - dys[k]
                    if (cx < 0 || cx >= roiW || cy < 0 || cy >= roiH) continue
                    acc[(cy shr 1) * aw + (cx shr 1)]++
                }
            }
            var bestS = 0
            var bgx = 0
            var bgy = 0
            for (gy in 0 until ah) {
                val row = gy * aw
                for (gx in 0 until aw) {
                    if (acc[row + gx] == 0) continue
                    var s = 0
                    for (yy in max(gy - 1, 0)..min(gy + 1, ah - 1)) {
                        for (xx in max(gx - 1, 0)..min(gx + 1, aw - 1)) s += acc[yy * aw + xx]
                    }
                    if (s > bestS) { bestS = s; bgx = gx; bgy = gy }
                }
            }
            val score = bestS.toDouble() / nr
            if (score > bestScore) {
                bestScore = score
                hCx = bgx * 2 + 1
                hCy = bgy * 2 + 1
                hR = radii[ri]
                found = true
            }
        }
        return found
    }

    /** 반지름 r 근처 띠 안에 픽셀이 둘레를 얼마나 덮는지(0~1), 띠 안/원 안쪽 픽셀 수 */
    private fun coverage(xs: IntArray, ys: IntArray, cnt: Int, cx: Double, cy: Double, r: Double) {
        var bins = 0
        var c = 0
        var inner = 0
        val m = min(cnt, NEW_CAP)
        for (p in 0 until m) {
            val dx = xs[p] - cx
            val dy = ys[p] - cy
            val d = sqrt(dx * dx + dy * dy)
            if (d >= r - 2 && d <= r + 2) {
                c++
                var b = (((atan2(dy, dx) + PI) / (2 * PI)) * NB).toInt() % NB
                if (b < 0) b += NB
                bins = bins or (1 shl b)
            } else if (d < r - 4) {
                inner++
            }
        }
        cntOut = c
        innerOut = inner
        covOut = if (c == 0) 0.0 else Integer.bitCount(bins).toDouble() / NB
    }

    /** 직전 반지름 근처(−4.5 ~ +1.5)만 보고 새 반지름을 측정 (플레이어/라켓 간섭 제거) */
    private fun radiusGated(c: Int, cx: Int, cy: Int, rPrev: Double): Boolean {
        val lo = rPrev - 4.5
        val hi = rPrev + 1.5
        java.util.Arrays.fill(rh, 0.0)
        var sel = 0
        val xs = newX[c]
        val ys = newY[c]
        val m = min(newTotal[c], NEW_CAP)
        for (p in 0 until m) {
            val dx = (xs[p] - cx).toDouble()
            val dy = (ys[p] - cy).toDouble()
            val d = sqrt(dx * dx + dy * dy)
            if (d >= lo && d <= hi) {
                val b = Math.rint(d).toInt()
                if (b >= 0 && b < rh.size) rh[b] += 1.0
                sel++
            }
        }
        if (sel < 8) return false
        var bi = 0
        var bv = -1.0
        for (i in rh.indices) {
            var s = rh[i]
            if (i > 0) s += rh[i - 1]
            if (i < rh.size - 1) s += rh[i + 1]
            if (s > bv) { bv = s; bi = i }
        }
        val a = max(bi - 2, 0)
        val b = min(bi + 3, rh.size)
        var sw = 0.0
        var sr = 0.0
        for (i in a until b) { sw += rh[i]; sr += i * rh[i] }
        resR = sr / max(sw, 1.0)
        coverage(xs, ys, m, cx.toDouble(), cy.toDouble(), resR)
        return true
    }
}
