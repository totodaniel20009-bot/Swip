// 위치: app/src/main/java/com/example/autoswipe/Config.kt
package com.example.autoswipe

import android.content.Context
import android.content.SharedPreferences

/** 사용자가 앱 화면에서 조절하는 설정값 */
data class Cfg(
    val stroke: Int,    // 타법: 0 커트, 1 드라이브, 2 블록, 3 랜덤
    val xPct: Int,      // 스와이프 가로 위치 (화면 너비 %)
    val yPct: Int,      // 스와이프 세로 중심 (화면 높이 %)
    val lenPct: Int,    // 위/아래 이동 거리 (화면 높이 %)
    val durMs: Int,     // 제스처 전체 소요 시간(ms)
    val leadMs: Int,    // 링이 목표에 닿기 몇 ms 전에 칠지
    val target: Int     // 목표 링 반지름(px, 기준 해상도)
)

object Config {
    const val PREFS = "autoswipe_cfg"
    const val STROKE_CUT = 0
    const val STROKE_DRIVE = 1
    const val STROKE_BLOCK = 2
    const val STROKE_RANDOM = 3

    fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun load(ctx: Context): Cfg {
        val p = prefs(ctx)
        return Cfg(
            stroke = p.getInt("stroke", STROKE_CUT).coerceIn(0, 3),
            xPct = p.getInt("x", 66).coerceIn(5, 95),
            yPct = p.getInt("y", 70).coerceIn(10, 90),
            lenPct = p.getInt("len", 12).coerceIn(3, 30),
            durMs = p.getInt("dur", 220).coerceIn(80, 600),
            leadMs = p.getInt("lead", 120).coerceIn(0, 500),
            target = p.getInt("target", 14).coerceIn(8, 30)
        )
    }
}
