// 위치: app/src/main/java/com/example/autoswipe/AutoSwipeAccessibilityService.kt
package com.example.autoswipe

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class AutoSwipeAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "AutoSwipeA11y"

        // ScreenCaptureService 가 직접 호출할 수 있도록 인스턴스를 보관
        @Volatile
        var instance: AutoSwipeAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "접근성 서비스 연결됨")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* 사용 안 함 */ }

    override fun onInterrupt() { /* 사용 안 함 */ }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    /**
     * 설정된 타법으로 한 번 친다. (메인 스레드에서 호출)
     *  - 커트   : 위로 올렸다가 아래로 쓸어내리기
     *  - 드라이브: 아래로 당겼다가 위로 밀기
     *  - 블록   : 톡(탭)
     *  - 랜덤   : 위 셋 중 무작위
     */
    fun performStroke(cfg: Cfg) {
        val (w, h) = screenSize()
        var type = cfg.stroke
        if (type == Config.STROKE_RANDOM) type = (0..2).random()

        val x = w * cfg.xPct / 100f
        val y0 = h * cfg.yPct / 100f
        val amp = h * cfg.lenPct / 100f
        val dx = w * 0.012f                 // 왕복 경로가 겹치지 않도록 살짝 비껴감
        val maxY = h - 2f

        val path = Path()
        var dur = cfg.durMs.toLong()
        when (type) {
            Config.STROKE_CUT -> {          // 위로 올렸다가 아래로
                path.moveTo(x, y0)
                path.lineTo(x, (y0 - amp).coerceIn(2f, maxY))
                path.lineTo(x + dx, (y0 + amp).coerceIn(2f, maxY))
            }
            Config.STROKE_DRIVE -> {        // 아래로 당겼다가 위로
                path.moveTo(x, y0)
                path.lineTo(x, (y0 + amp).coerceIn(2f, maxY))
                path.lineTo(x + dx, (y0 - amp).coerceIn(2f, maxY))
            }
            else -> {                       // 블록: 탭
                path.moveTo(x, y0)
                dur = 40L
            }
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0L, dur))
            .build()

        val ok = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCancelled(gestureDescription: GestureDescription?) {
                Log.w(TAG, "제스처 취소됨")
            }
        }, null)
        if (!ok) Log.w(TAG, "dispatchGesture 실패")
    }

    private fun screenSize(): Pair<Int, Int> {
        val wm = getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }
}
